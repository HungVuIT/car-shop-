<?php
include_once('../libs/session.php');
include_once('../libs/database.php');
include_once('../libs/role.php');
include_once('../libs/helper.php');
if (is_submit('delete_car')) {
    // Lấy ID và ép kiểu
    $id = input_post('id');
    $sql = "DELETE FROM car where id = '$id'";
    db_execute($sql);
    redirect(base_url('admin/carAdmin.php'));
}
if (is_submit('edit_car')) {
    $id = input_post('id');

    $name = input_post('name');
    $brand = input_post('brand');
    $year = input_post('year');
    $seats = input_post('seats');
    $color = input_post('color');
    $engine = input_post('engine');
    $price = input_post('price');
    $description = input_post('description');
    /*$sql = "UPDATE car SET name='$name', brand='$brand', year='$year', 
    seats='$seats', color='$color', engine='$engine', price='$price', 
    description='$description' WHERE id='$id'";*/
    // Upload image

    $target_dir = "carImg/";
    $carImageName1 = time() . '-' . $_FILES["carImage1$id"]["name"];
    $target_file1 = $target_dir . basename($carImageName1);
    $photo_tmp_name1 = $_FILES["carImage1$id"]["tmp_name"];
    $photo_size1 = $_FILES["carImage1$id"]["size"];
    $photo_new_name1 = rand() . $carImageName1;

    $carImageName2 = time() . '-' . $_FILES["carImage2$id"]["name"];
    $target_file2 = $target_dir . basename($carImageName2);
    $photo_tmp_name2 = $_FILES["carImage2$id"]["tmp_name"];
    $photo_size2 = $_FILES["carImage2$id"]["size"];
    $photo_new_name2 = rand() . $carImageName2;

    $carImageName3 = time() . '-' . $_FILES["carImage3$id"]["name"];
    $target_file3 = $target_dir . basename($carImageName3);
    $photo_tmp_name3 = $_FILES["carImage3$id"]["tmp_name"];
    $photo_size3 = $_FILES["carImage3$id"]["size"];
    $photo_new_name3 = rand() . $carImageName3;

    if (!preg_match("/\\.(gif|jpg|png)$/i", $carImageName1)) {
        $msg = "Your image file was not jpg, gif or png type";
        $msg_class = "alert-danger";
        exit();
    } else if (!preg_match("/\\.(gif|jpg|png)$/i", $carImageName2)) {
        $msg = "Your image file was not jpg, gif or png type";
        $msg_class = "alert-danger";
        exit();
    } else if (!preg_match("/\\.(gif|jpg|png)$/i", $carImageName3)) {
        $msg = "Your image file was not jpg, gif or png type";
        $msg_class = "alert-danger";
        exit();
    } else if (move_uploaded_file($photo_tmp_name1, $target_file1) and move_uploaded_file($photo_tmp_name2, $target_file2) and move_uploaded_file($photo_tmp_name3, $target_file3)) {
        $sql = "UPDATE car SET name='$name', brand='$brand', year='$year', 
        seats='$seats', color='$color', engine='$engine', price='$price', 
        description='$description', car_img1='$carImageName1', car_img2='$carImageName2', car_img3='$carImageName3' WHERE id='$id'";
    }
    db_execute($sql);
    redirect(base_url('admin/carAdmin.php'));
}
if (is_submit('add_car')) {
    $name = input_post('name');
    $brand = input_post('brand');
    $year = input_post('year');
    $seats = input_post('seats');
    $color = input_post('color');
    $engine = input_post('engine');
    $price = input_post('price');
    $trasmission = input_post('trasmission');
    $warranty = input_post('warranty');
    $description = input_post('description');

    $target_dir = "carImg/";
    $carImageName1 = time() . '-' . $_FILES["carImage1add"]["name"];
    $target_file1 = $target_dir . basename($carImageName1);
    $photo_tmp_name1 = $_FILES["carImage1add"]["tmp_name"];
    $photo_size1 = $_FILES["carImage1add"]["size"];
    $photo_new_name1 = rand() . $carImageName1;

    $carImageName2 = time() . '-' . $_FILES["carImage2add"]["name"];
    $target_file2 = $target_dir . basename($carImageName2);
    $photo_tmp_name2 = $_FILES["carImage2add"]["tmp_name"];
    $photo_size2 = $_FILES["carImage2add"]["size"];
    $photo_new_name2 = rand() . $carImageName2;

    $carImageName3 = time() . '-' . $_FILES["carImage3add"]["name"];
    $target_file3 = $target_dir . basename($carImageName3);
    $photo_tmp_name3 = $_FILES["carImage3add"]["tmp_name"];
    $photo_size3 = $_FILES["carImage3add"]["size"];
    $photo_new_name3 = rand() . $carImageName3;
    if (!preg_match("/\\.(gif|jpg|png)$/i", $carImageName1)) {
        $msg = "Your image file was not jpg, gif or png type";
        $msg_class = "alert-danger";
        exit();
    } else if (!preg_match("/\\.(gif|jpg|png)$/i", $carImageName2)) {
        $msg = "Your image file was not jpg, gif or png type";
        $msg_class = "alert-danger";
        exit();
    } else if (!preg_match("/\\.(gif|jpg|png)$/i", $carImageName3)) {
        $msg = "Your image file was not jpg, gif or png type";
        $msg_class = "alert-danger";
        exit();
    } else if (move_uploaded_file($photo_tmp_name1, $target_file1) and move_uploaded_file($photo_tmp_name2, $target_file2) and move_uploaded_file($photo_tmp_name3, $target_file3)) {
        $sql = "INSERT INTO car (name,brand,year,seats,color,transmission,engine,price,warranty,description,car_img1,car_img2,car_img3)
    VALUES ('$name','$brand','$year','$seats','$color','$trasmission','$engine','$price','$warranty','$description','$carImageName1','$carImageName2','$carImageName3')";;
    }
    db_execute($sql);
    redirect(base_url('admin/carAdmin.php'));
}
?>