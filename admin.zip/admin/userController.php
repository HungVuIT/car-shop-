<?php
include_once('../libs/session.php');
include_once('../libs/database.php');
include_once('../libs/role.php');
include_once('../libs/helper.php');
if (is_submit('delete_user'))
{
    // Lấy ID và ép kiểu
    $id = input_post('id');
    $sql = 'DELETE FROM user where id = ' . $id;
    db_execute($sql); 
    redirect(base_url('admin/userAdmin.php'));
}
?>