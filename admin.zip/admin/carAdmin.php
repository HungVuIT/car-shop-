<?php
include_once('../libs/session.php');
include_once('../libs/database.php');
include_once('../libs/role.php');
include_once('../libs/helper.php');
$sql = db_create_sql("SELECT * FROM car");
$car = db_get_list($sql);
$msg = "";
$msg_class = "";
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, Ample lite admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, Ample admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description" content="Ample Admin Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>Ample Admin Lite Template by WrapPixel</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/ample-admin-lite/" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="//code.jquery.com/jquery.js"></script>
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <link href="css/style.min.css" rel="stylesheet">
    <link href="css/car.css" rel="stylesheet">
    <script type="text/javascript" src="js/car.js"></script>
    <style>
        #btn_contact {
            margin-top: 100px;
            margin-left: 100px;
            width: 30%;
            height: 50px;
            float: inline-end;
        }
    </style>
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full" data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <?php
        include_once('header.php');
        include_once('aside.php');
        ?>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb bg-white">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Basic Table</h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <div class="d-md-flex">
                            <ol class="breadcrumb ms-auto">
                                <li><a href="#" class="fw-normal">Dashboard</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <h2 class="box-title">LIST OF PRODUCT</h2>
                            <div class="table-responsive">
                                <table class="table text-nowrap">
                                    <thead>
                                        <tr>
                                            <th class="border-top-0">Name</th>
                                            <th class="border-top-0">Brand</th>
                                            <th class="border-top-0">Price</th>
                                            <th class="border-top-0">Design</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($car as $item) { ?>
                                            <tr>
                                                <td><?php echo $item['name']; ?></td>
                                                <td><?php echo $item['brand']; ?></td>
                                                <td><?php echo $item['price']; ?></td>
                                                <td>
                                                    <div class="box1">
                                                        <div class="box2">
                                                            <div class="box3">
                                                                <?php
                                                                if (empty($item['car_img1'])) :
                                                                ?>
                                                                    <img class="carImg" src="carImg/default.png">
                                                                <?php else : ?>
                                                                    <img class="carImg" src="<?php echo 'carImg/' . $item['car_img1'] ?>" alt="avatar">
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="col-md-12">
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <form method="POST" class="form-delete" action="carController.php">
                                                                    <input type="hidden" name="id" value="<?php echo $item['id']; ?>" />
                                                                    <input type="hidden" name="request_name" value="delete_car" />
                                                                    <button class="btn btn-danger">Delete</button>
                                                                </form>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#model<?php echo $item['id']; ?>">Detail & Edit</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- ============================================================== -->
                                                    <!-- JS FOR EACH CAR -->
                                                    <!-- ============================================================== -->
                                                    <script>
                                                        function triggerClick1<?php echo $item['id']; ?>() {
                                                            document.querySelector('#carImage1<?php echo $item['id']; ?>').click();
                                                        }

                                                        function displayImage1<?php echo $item['id']; ?>(e) {
                                                            if (e.files[0]) {
                                                                var reader = new FileReader();

                                                                reader.onload = function(e) {
                                                                    document.querySelector('#carDisplay1<?php echo $item['id']; ?>').setAttribute('src', e.target.result);
                                                                }

                                                                reader.readAsDataURL(e.files[0]);
                                                            }
                                                        }

                                                        function triggerClick2<?php echo $item['id']; ?>() {
                                                            document.querySelector('#carImage2<?php echo $item['id']; ?>').click();
                                                        }

                                                        function displayImage2<?php echo $item['id']; ?>(e) {
                                                            if (e.files[0]) {
                                                                var reader = new FileReader();

                                                                reader.onload = function(e) {
                                                                    document.querySelector('#carDisplay2<?php echo $item['id']; ?>').setAttribute('src', e.target.result);
                                                                }

                                                                reader.readAsDataURL(e.files[0]);
                                                            }
                                                        }

                                                        function triggerClick3<?php echo $item['id']; ?>() {
                                                            document.querySelector('#carImage3<?php echo $item['id']; ?>').click();
                                                        }

                                                        function displayImage3<?php echo $item['id']; ?>(e) {
                                                            if (e.files[0]) {
                                                                var reader = new FileReader();

                                                                reader.onload = function(e) {
                                                                    document.querySelector('#carDisplay3<?php echo $item['id']; ?>').setAttribute('src', e.target.result);
                                                                }

                                                                reader.readAsDataURL(e.files[0]);
                                                            }
                                                        }
                                                    </script>
                                                    <!-- ============================================================== -->
                                                    <!-- EDIT MODEL -->
                                                    <!-- ============================================================== -->
                                                    <div class="modal fade" id="model<?php echo $item['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-centered modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <legend class="text-center">CAR INFOMATION</legend>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="well well-sm">
                                                                        <!-- ============================================================== -->
                                                                        <!-- FORM PLACE -->
                                                                        <!-- ============================================================== -->
                                                                        <form class="" action="carController.php" method="post" enctype="multipart/form-data">
                                                                            <div class="form-row">
                                                                                <div class="form-group">
                                                                                    <div class="col-md-12">
                                                                                        <div class="row">

                                                                                            <input type="hidden" name="id" value="<?php echo $item['id']; ?>" />
                                                                                            <input type="hidden" name="request_name" value="edit_car" />
                                                                                            <div class="col-md-6"><label class="labels">Name</label><input type="text" class="form-control" id="name" name="name" value="<?php echo $item['name']; ?>" required></div>
                                                                                            <div class="col-md-6"><label class="labels">Brand</label><input type="text" class="form-control" id="brand" name="brand" value="<?php echo $item['brand']; ?>" required></div>

                                                                                            <div class="col-md-6"><label class="labels">Year</label><input type="text" class="form-control" id="year" name="year" value="<?php echo $item['year']; ?>"></div>
                                                                                            <div class="col-md-6"><label class="labels">Seats</label><input type="text" class="form-control" id="seats" name="seats" value="<?php echo $item['seats']; ?>" required></div>

                                                                                            <div class="col-md-6"><label class="labels">Color</label><input type="text" class="form-control" id="color" name="color" value="<?php echo $item['color']; ?>" required></div>
                                                                                            <div class="col-md-6"><label class="labels">Engine</label><input type="text" class="form-control" id="engine" name="engine" value="<?php echo $item['engine']; ?>" required></div>

                                                                                            <div class="col-md-6"><label class="labels">Price</label><input type="text" class="form-control" id="price" name="price" value="<?php echo $item['price']; ?>" required></div>
                                                                                            <div class="col-md-12"><label class="labels">Description</label><input type="text" class="form-control" id="description" name="description" value="<?php echo $item['description']; ?>" required></div>
                                                                                            <!-- Upload image -->
                                                                                            <div class="box1">
                                                                                                <div class="box2">
                                                                                                    <div class="box3">
                                                                                                        <div class="text-center img-placeholder" onClick="triggerClick1<?php echo $item['id']; ?>()">
                                                                                                            <h4>Update image</h4>
                                                                                                        </div>
                                                                                                        <?php

                                                                                                        if (empty($item['car_img1'])) :

                                                                                                        ?>
                                                                                                            <img class="carImg" src="carImg/default.png" onClick="triggerClick1<?php echo $item['id']; ?>()" id="carDisplay1<?php echo $item['id']; ?>">
                                                                                                        <?php else : ?>
                                                                                                            <img class="carImg" src="<?php echo 'carImg/' . $item['car_img1'] ?>" alt="avatar" onClick="triggerClick1<?php echo $item['id']; ?>()" id="carDisplay1<?php echo $item['id']; ?>">
                                                                                                        <?php endif; ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <input type="file" accept=".jpg,.jpeg,.png" name="carImage1<?php echo $item['id']; ?>" onChange="displayImage1<?php echo $item['id']; ?>(this)" id="carImage1<?php echo $item['id']; ?>" class="form-control" style="display: none;">

                                                                                            </div>
                                                                                            <!-- End upload image -->
                                                                                            <!-- Upload image -->
                                                                                            <div class="box1">
                                                                                                <div class="box2">
                                                                                                    <div class="box3">
                                                                                                        <div class="text-center img-placeholder" onClick="triggerClick2<?php echo $item['id']; ?>()">
                                                                                                            <h4>Update image</h4>
                                                                                                        </div>
                                                                                                        <?php

                                                                                                        if (empty($item['car_img2'])) :

                                                                                                        ?>
                                                                                                            <img class="carImg" src="carImg/default.png" onClick="triggerClick2<?php echo $item['id']; ?>()" id="carDisplay2<?php echo $item['id']; ?>">
                                                                                                        <?php else : ?>
                                                                                                            <img class="carImg" src="<?php echo 'carImg/' . $item['car_img2'] ?>" alt="avatar" onClick="triggerClick2<?php echo $item['id']; ?>()" id="carDisplay2<?php echo $item['id']; ?>">
                                                                                                        <?php endif; ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <input type="file" accept=".jpg,.jpeg,.png" name="carImage2<?php echo $item['id']; ?>" onChange="displayImage2<?php echo $item['id']; ?>(this)" id="carImage2<?php echo $item['id']; ?>" class="form-control" style="display: none;">

                                                                                            </div>
                                                                                            <!-- End upload image -->
                                                                                            <!-- Upload image -->
                                                                                            <div class="box1">
                                                                                                <div class="box2">
                                                                                                    <div class="box3">
                                                                                                        <div class="text-center img-placeholder" onClick="triggerClick3<?php echo $item['id']; ?>()">
                                                                                                            <h4>Update image</h4>
                                                                                                        </div>
                                                                                                        <?php

                                                                                                        if (empty($item['car_img3'])) :

                                                                                                        ?>
                                                                                                            <img class="carImg" src="carImg/default.png" onClick="triggerClick3<?php echo $item['id']; ?>()" id="carDisplay3<?php echo $item['id']; ?>">
                                                                                                        <?php else : ?>
                                                                                                            <img class="carImg" src="<?php echo 'carImg/' . $item['car_img3'] ?>" alt="avatar" onClick="triggerClick3<?php echo $item['id']; ?>()" id="carDisplay3<?php echo $item['id']; ?>">
                                                                                                        <?php endif; ?>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <input type="file" accept=".jpg,.jpeg,.png" name="carImage3<?php echo $item['id']; ?>" onChange="displayImage3<?php echo $item['id']; ?>(this)" id="carImage3<?php echo $item['id']; ?>" class="form-control" style="display: none;">

                                                                                            </div>
                                                                                            <!-- End upload image -->

                                                                                        </div>

                                                                                        <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="submit" name="submit">Save</button></div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- ============================================================== -->
                                                    <!-- END EDIT MODEL -->
                                                    <!-- ============================================================== -->
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>

                                <button type="button" class="btn btn-outline-dark" id="btn_contact" data-toggle="modal" data-target="#addModel">
                                    <H2>Add new</H2>
                                </button>

                                <!-- ============================================================== -->
                                <!-- ADD MODEL -->
                                <!-- ============================================================== -->
                                <div class="modal fade" id="addModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <legend class="text-center">ADD NEW CAR</legend>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="well well-sm">
                                                    <!-- ============================================================== -->
                                                    <!-- FORM PLACE -->
                                                    <!-- ============================================================== -->
                                                    <form action="carController.php" method="post" enctype="multipart/form-data">
                                                        <div class="form-row">
                                                            <div class="form-group">
                                                                <div class="col-md-12">
                                                                    <div class="row">
                                                                        <input type="hidden" name="request_name" value="add_car" />
                                                                        <div class="col-md-6"><label class="labels">Name</label><input type="text" class="form-control" id="name" name="name" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Brand</label><input type="text" class="form-control" id="brand" name="brand" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Year</label><input type="text" class="form-control" id="year" name="year" value=""></div>
                                                                        <div class="col-md-6"><label class="labels">Seats</label><input type="text" class="form-control" id="seats" name="seats" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Color</label><input type="text" class="form-control" id="color" name="color" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Engine</label><input type="text" class="form-control" id="engine" name="engine" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Price</label><input type="text" class="form-control" id="price" name="price" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Warranty</label><input type="text" class="form-control" id="warranty" name="warranty" value="" required></div>
                                                                        <div class="col-md-6"><label class="labels">Transmission</label><input type="text" class="form-control" id="transmission" name="transmission" value="" required></div>
                                                                        <div class="col-md-12"><label class="labels">Description</label><input type="text" class="form-control" id="description" name="description" value="" required></div>
                                                                        <!-- Upload image -->
                                                                        <div class="box1">
                                                                            <div class="box2">
                                                                                <div class="box3">
                                                                                    <div class="text-center img-placeholder" onClick="triggerClick1add()">
                                                                                        <h4>Update image</h4>
                                                                                    </div>

                                                                                    <img class="carImg" src="carImg/default.png" onClick="triggerClick1add()" id="carDisplay1add">

                                                                                </div>
                                                                            </div>
                                                                            <input type="file" accept=".jpg,.jpeg,.png" name="carImage1add" onChange="displayImage1add(this)" id="carImage1add" class="form-control" style="display: none;">

                                                                        </div>
                                                                        <!-- End upload image -->
                                                                        <!-- Upload image -->
                                                                        <div class="box1">
                                                                            <div class="box2">
                                                                                <div class="box3">
                                                                                    <div class="text-center img-placeholder" onClick="triggerClick2add()">
                                                                                        <h4>Update image</h4>
                                                                                    </div>

                                                                                    <img class="carImg" src="carImg/default.png" onClick="triggerClick2add()" id="carDisplay2add">

                                                                                </div>
                                                                            </div>
                                                                            <input type="file" accept=".jpg,.jpeg,.png" name="carImage2add" onChange="displayImage2add(this)" id="carImage2add" class="form-control" style="display: none;">

                                                                        </div>
                                                                        <!-- End upload image -->
                                                                        <!-- Upload image -->
                                                                        <div class="box1">
                                                                            <div class="box2">
                                                                                <div class="box3">
                                                                                    <div class="text-center img-placeholder" onClick="triggerClick3add()">
                                                                                        <h4>Update image</h4>
                                                                                    </div>

                                                                                    <img class="carImg" src="carImg/default.png" onClick="triggerClick3add()" id="carDisplay3add">

                                                                                </div>
                                                                            </div>
                                                                            <input type="file" accept=".jpg,.jpeg,.png" name="carImage3add" onChange="displayImage3add(this)" id="carImage3add" class="form-control" style="display: none;">

                                                                        </div>
                                                                        <!-- End upload image -->
                                                                    </div>

                                                                    <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="submit" name="submit">Add Car</button></div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- ============================================================== -->
                                <!-- END EDIT MODEL -->
                                <!-- ============================================================== -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer text-center"> 2021 © Ample Admin brought to you by <a href="https://www.wrappixel.com/">wrappixel.com</a>
            </footer>
        </div>
    </div>
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.js"></script>
</body>

</html>