<?php
include_once('../libs/session.php');
include_once('../libs/database.php');
include_once('../libs/role.php');
include_once('../libs/helper.php');
if (is_submit('delete_user'))
{
    // Lấy ID và ép kiểu
    $id = input_post('user_id');
    $sql = 'DELETE FROM contact where id = ' . $id;
    db_execute($sql); 
    redirect(base_url('admin/basic-table.php'));
}
if (is_submit('add_user'))
{
    $name = input_post('name');
    $email = input_post('name');
    $mess = input_post('mess');
    $sql = "INSERT INTO contact (name,email,message)
        VALUES ('$name', '$email', '$mess')";
    db_execute($sql); 
    redirect(base_url('admin/basic-table.php'));
}
?>